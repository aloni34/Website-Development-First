﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    public string stam;
    public string stam2;
   
    protected void Page_Load(object sender, EventArgs e)
    {
       
        string time;
        stam = "<div style =\"font-size:48px\">Alon</h1>";
        Response.Write("<h1 style=\"color:red;background:black;text-align:left\">" + stam+"</h1>");
        stam2 = "yehezkel";
        Response.Write("<h1 style=\"color:red;background:black;text-align:left\">" + stam2 + "</h1>");
        time = DateTime.Now.ToString();
      
        for (int i = 1; i <=100; i++)
        {

            int num1 = i * 4;
            int num2 = (i * 4)+40;
            int num3 = (i * 4)+80;
            double num4 = (i * 0.2)+5;
            if (i >= 50)
            {
                 num1 = i * 4 - (i*2);
                 num2 = (i * 4) - (i) + 40;
                 num3 = (i * 4) - (i) + 80;
                 num4 = (i * 0.2) + 10 - (i*0.05);
            }
            string temp = String.Format("<h1 style =\"font-size:{0};color: rgb({1},{2},{3});text-align:left\">{4}</h1>", num4,num1,num2,num3,stam2);
           
            Response.Write(temp);
        }
      
        Response.Write("<div style=\"text-align:left\">" + time+"</div>");
        for (int i = 1; i <= 100; i++)
        {
           int num1 = i;
            if (num1%3==0)
            {
                Response.Write( num1 + "<br>");
              
            }
        }
        
        Random rnd = new Random();
        int random1 = rnd.Next(1, 10);
        int random2 = rnd.Next(1, 10);
        double power_total = 0;
        Response.Write("<div style=\"text-align:left; color:red;\">" + "your plus is:" + (random1 + random2) + "</div>");
        Response.Write("<div style=\"text-align:left; color:orange;\">" + "your minus is:" + (random1-random2) + "</div>");
        Response.Write("<div style=\"text-align:left; color:yellow;\">" + "your multiplay is:" + (random1 * random2) + "</div>");
        Response.Write("<div style=\"text-align:left; color:green;\">" + "your divided is:" + (random1 / random2) + "</div>");
        power_total = Math.Pow(random1, random2);
        Response.Write("<div style=\"text-align:left; color:blue;\">" + "your power is:" + power_total + "</div>");
        Response.Write("<div style=\"text-align:left; color:gray;\">" + "The numbers are: (1) " + random1 + " and: (2) " + random2 + "</div>");


        Response.Write("<table>");
        for (int i = 1; i <= 20; i++)
        {
            Response.Write("<tr>");
            for (int j = 1; j <= 20; j++)
            {
                Response.Write("<td>"+j*i+"</td>");
            }
            Response.Write("</tr>");
        }
        Response.Write("</table>");
    }
}