﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_UpdatePassword : System.Web.UI.Page
{
    public String Updatequerry, S1, S2, S3;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Request.Form["submit"] != null)
        {
            S1 = Request.Form["Password1"];
            S2 = Request.Form["Password2"];
            if (Session["User"] != null)
            {
                if(S1.Equals(S2) && S1 != "" && S2 != "")
                {
                    Updatequerry = "UPDATE Table1 set password='" + S1 + "' where mail='" + Session["User"] + "'";
                    MyAdoHelper.DoQuery(Updatequerry);
                    S3 = "Update sucessfully";
                }
                else
                {
                    S3 = "Not the same password";
                }
            }
        }      
    }
}