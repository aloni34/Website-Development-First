﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class input1 : System.Web.UI.Page
{
    public string S1, S2, S3;
    protected void Page_Load(object sender, EventArgs e)
    {
        String k1, k2, k3;
        k1 = Request.QueryString["N1"];
        k2 = Request.QueryString["N2"];
        k3 = Request.QueryString["N3"];
       
            S1 = k1;      
            S2 = k2;   
            S3 = k3;
      

    }
}