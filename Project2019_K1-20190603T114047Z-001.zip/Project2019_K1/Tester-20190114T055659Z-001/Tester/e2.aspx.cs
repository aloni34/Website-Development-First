﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_e2 : System.Web.UI.Page
{
    public string S1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Form["submit2"] != null)
        {
            if (Request.Form["submit"] == null)
            {
                if (Request.Form["check1"] == "legs")
                {
                    Response.Redirect("e3.aspx");
                }
            }
        }
    }
}