﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Tester_20190114T055659Z_001_Tester_ShowData : System.Web.UI.Page
{
    
    public string st, sql;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Form["submit"] != null)
        {
            
            string s1 = Request.Form["Fname"];
            string s2 = Request.Form["Lastname"];
          
            if (String.IsNullOrEmpty(s1) && String.IsNullOrEmpty(s2))
            {
                 sql = "Select * from Table1";
            }
            else if(String.IsNullOrEmpty(s1))
            {
                sql = "Select * from Table1 where Lastname like '%" + s2 +"%'";
            }
            else if(String.IsNullOrEmpty(s2))
            {
                sql = "Select * from Table1 where Firstname like '%" + s1 + "%'";
            }
            else
            {
                sql = "Select * from Table1 where Firstname like '%" + s2 + "%' and lastname like '%" + s1 + "%'";
            }
            DataTable dt = MyAdoHelper.ExecuteSelect(sql);
            st += "<table border ='1' align='left' style=font-size:22px;>";
            st += "<tr style = color:aqua;><td>password</td><td>Firstname</td><td>Lastname</td><td>Phone</td><td>Mail</td><td>Gender</td><td>AreaCode</td><td>Age</td><td>Interests</td><td>Address</td><td>Training</td><td>Food</td></tr>";

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                st += "<tr>";

                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    st += "<td>" + dt.Rows[i][j] + "</td>";
                }

                st += "</tr>";
            }
            st += "</table>";
        }
       
    }
}