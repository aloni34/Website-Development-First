﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_Change : System.Web.UI.Page
{
    public string S1, S2, S3, S4, S5, S6, S7 = "", S8 = "",S9, S10 = "", S11 = "", S12 = "", S13 = "", problem = "", updatequeery, selectqueery;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Form["submit"] != null)
        {

            S1 = Request.Form["Firstname"];
            S2 = Request.Form["Lastname"];
            S3 = Request.Form["Password"];
            S4 = Request.Form["Password2"];
            S5 = Request.Form["Phone"];
            S6 = Request.Form["mail"];         
            S9 = Request.Form["age"];         
            
            selectqueery = "SELECT * From Table1" + " Where mail='" + S6 + "'";

            if (Request.Form["Gender"] != null)
            {
                S7 = Request.Form["Gender"].ToString();
            }
            if (Request.Form["areaCode"] != null)
            {
                S8 = Request.Form["areaCode"].ToString();
            }
            if (Request.Form["Site1"] != null)
            {
                S10 = Request.Form["Site1"].ToString();
            }
            if (Request.Form["Address"].ToString() != " ")
            {
                S11 = Request.Form["Address"];
            }
            if (Request.Form["Training"] != null)
            {
                S12 = Request.Form["Training"].ToString();
            }
            if (Request.Form["Food"] != null)
            {
                S13 = Request.Form["Food"].ToString();
            }

            if (MyAdoHelper.Exists(selectqueery))
            {
                if(Request.Form["mail"] != "Admin" && Request.Form["Password"].Equals(Request.Form["Password2"]))
                { 
                    if (S1 != "")
                    {
                        updatequeery = "UPDATE Table1 set Firstname='" + S1 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S2 != "")
                    {
                        updatequeery = "UPDATE Table1 set lastname='" + S2 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S3 != "" && S4 != "" && S3.Equals(S4))
                    {
                        updatequeery = "UPDATE Table1 set password='" + S3 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S5 != "")
                    {
                        updatequeery = "UPDATE Table1 set Phone='" + S5 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S7 != "")
                    {
                        updatequeery = "UPDATE Table1 set gender='" + S7 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S8 != "")
                    {
                        updatequeery = "UPDATE Table1 set areacode='" + S8 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if(S9 != "")
                    {
                        updatequeery = "UPDATE Table1 set age='" + S9 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S10 != "")
                    {
                        updatequeery = "UPDATE Table1 set interests='" + S10 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S11 != "")
                    {
                        updatequeery = "UPDATE Table1 set Address='" + S11 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S12 != "")
                    {
                        updatequeery = "UPDATE Table1 set Training='" + S12 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                    if (S13 != "")
                    {
                        updatequeery = "UPDATE Table1 set Food='" + S13 + "' where mail='" + S6 + "'";
                        MyAdoHelper.DoQuery(updatequeery);
                    }
                   
                    Response.Redirect("AdminManage.aspx");
                }
                else
                {
                    problem = "Cant update any of the settings, are you the Admin :) ?";
                }
            }
            else
            {
                problem = "The email does not exists";
            }
        }
    }
}