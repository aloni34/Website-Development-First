﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_Exit : System.Web.UI.Page
{
    public String Show;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Page.IsPostBack)
        {          
            if (Request.Form["submit1"] != null)
            {
                Session.Abandon();
                Response.Redirect("login.aspx");
            }
            else
            {
                if(Session["Admin"] != null)
                {
                    Response.Redirect("AdminManage.aspx");
                }
                else
                {
                    Response.Redirect("MemberWelcome.aspx");
                }
            }
        }
    }
}