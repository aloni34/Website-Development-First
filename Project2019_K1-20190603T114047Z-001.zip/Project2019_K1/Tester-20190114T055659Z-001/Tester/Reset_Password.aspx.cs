﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net.Mail;

public partial class Tester_20190114T055659Z_001_Tester_Reset_Password : System.Web.UI.Page
{
    public String S1,S2, Selectquerry, st;
    protected void Page_Load(object sender, EventArgs e)
    {
      

     if (Session["ConfirmMail"] != null)
        {
            string mailToSend = Session["ConfirmMail"].ToString();
          
            Selectquerry = "SELECT password From Table1" + " Where mail='" + Session["ConfirmMail"] + "'";
            DataTable Find = MyAdoHelper.ExecuteSelect(Selectquerry);
            for (int i = 0; i < Find.Rows.Count; i++)
            {
                { 
                    S1 = ""+Find.Rows[i][0]+"";
                    S2 = "Your password as been sent to your mail!";
                }          
            }
            sendMail(mailToSend);
        }
    }
    public void sendMail(string detination)
    {
        SmtpClient client = new SmtpClient();
        client.DeliveryMethod = SmtpDeliveryMethod.Network;
        client.EnableSsl = true;
        client.Host = "smtp.gmail.com";
        client.Port = 587;

      
        System.Net.NetworkCredential credentials =
        new System.Net.NetworkCredential("tester555findandsend@gmail.com", "F4f4F4F4");
        client.UseDefaultCredentials = false;
        client.Credentials = credentials;

        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("tester555findandsend@gmail.com");
        msg.To.Add(new MailAddress(detination));

        msg.Subject = "This is a test Email subject";
        msg.IsBodyHtml = true;
        msg.Body = string.Format("<html><head></head><body><b>"+S1+"</b></body>");


        client.Send(msg);

    }
}