﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Tester_20190114T055659Z_001_Tester_DeleteUser : System.Web.UI.Page
{
    public string Say = "",S2, S1, S0, Deletequerry;
    protected void Page_Load(object sender, EventArgs e)
    {


        S0 = ""+Session["S1"]+"";
        S1 = ""+Session["S2"]+"";
        S2 = ""+Session["S3"]+"";

        if(Request.Form["submit"] != null)
        {
            if(S0 != "Admin")
            {
                Deletequerry = "DELETE From Table1" + " Where mail='" + S0 + "'";
                MyAdoHelper.DoQuery(Deletequerry);
                Response.Redirect("AdminManage.aspx");
            }
           else
            {
                S0 = "";
                S1 = "";
                S2 = "";
                Say = "Can't delete the admin";
            }
        }
    }
}