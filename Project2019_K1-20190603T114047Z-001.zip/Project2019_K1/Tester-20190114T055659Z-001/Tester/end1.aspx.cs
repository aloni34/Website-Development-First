﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_end1 : System.Web.UI.Page
{
    // A
    public string result1, sum, i1, i2, i3;
    public int numj2_int, numj1_int;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            
           
                int tal1=0;
                if (txtTal1.Text != "")
                tal1 = Convert.ToInt16(txtTal1.Text);
                int tal2=0;
                if (txtTal2.Text != "")
                    tal2 = Convert.ToInt16(txtTal2.Text);
                int result1 = tal1 + tal2;
                lblresult.Text = result1.ToString();
           
           
               
        }




        // End

    }


    protected void btnCalculate_click(object sender, EventArgs e)
    {
       
    }

}