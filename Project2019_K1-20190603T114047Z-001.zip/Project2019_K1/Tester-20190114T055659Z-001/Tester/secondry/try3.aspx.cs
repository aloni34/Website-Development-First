﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_secondry_try3 : System.Web.UI.Page
{
    public string gender_string;
    public int gender;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            gender_string = Request.Form["gender"];
            Response.Write("<h1> " + gender_string + " </h1>");
            string sql_command = "insert into Table2 (id,gender) VALUES('3599', '" + gender_string + "')";
            int x = MyAdoHelper.RowsAffected(sql_command);
            if (x == 1)
                if (gender_string.Equals("1"))
                    Response.Write("Successful insertion of a female");
                else
                    Response.Write("Successful insertion of a male");
            else
                Response.Write("UnSuccessful insertion");
        }
    }
}