﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_secondry_try : System.Web.UI.Page
{
    public string name;
    public string sql_command;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            name = Request.Form["userName"];
            Response.Write(name);
            Response.Write("<h1> " + name + " </h1>");
            string sql_command = "insert into Table1 (id,Firstname) VALUES('3435', '" + name + "')";
            Response.Write(sql_command);

            //int x = MyAdoHelper.RowsAffected(sql_command);
            //if (x == 1)
            //    Response.Write("Successful insertion");
            //else
            //    Response.Write("UnSuccessful insertion");

        }
    }
}