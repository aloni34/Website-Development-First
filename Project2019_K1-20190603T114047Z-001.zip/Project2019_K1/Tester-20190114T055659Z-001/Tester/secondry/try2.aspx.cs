﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tester_20190114T055659Z_001_Tester_secondry_try2 : System.Web.UI.Page
{
    public string age_string;
    public int age;
    public string sql_command;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            age_string = Request.Form["userAge"];
            age = int.Parse(age_string);
            Response.Write("<h1> " + age + " </h1>");
            string sql_command = "insert into Table2 (id,age)  VALUES('3442', '" + age + "')";
            int x = MyAdoHelper.RowsAffected(sql_command);
            if (x == 1)
                Response.Write("Successful insertion");
            else
                Response.Write("UnSuccessful insertion");
        }
    }
}
