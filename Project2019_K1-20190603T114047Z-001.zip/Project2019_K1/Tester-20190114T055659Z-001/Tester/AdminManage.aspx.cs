﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Tester_20190114T055659Z_001_Tester_AdminManage : System.Web.UI.Page
{
    public string st, sql, select1, select2, select3;
    protected void Page_Load(object sender, EventArgs e)
    {
        sql = "Select * from Table1";
        DataTable dt = MyAdoHelper.ExecuteSelect(sql);

        st += "<table border ='1' align='left' style=font-size:22px;>";
        st += "<tr style = color:aqua;><td>password</td><td>Firstname</td><td>Lastname</td><td>Phone</td><td>Mail</td><td>Gender</td><td>AreaCode</td><td>Age</td><td>Interests</td><td>Address</td><td>Training</td><td>Food</td><td>Update</td><td>Delete</td></tr>";

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            st += "<tr>";

            for (int j = 0; j < dt.Columns.Count; j++)
            {
                st += "<td>" + dt.Rows[i][j] + "</td>";
            }
            st += "<td><form name=form1 method=post action=AdminManage.aspx runat=server> <input type=submit name=Update'" + i + "' id=Update'" + i + "'  value=Update style=font - size:32px; color: red; /></form></td></td>";
            st += "<td> <form name=form1 method=post action=AdminManage.aspx runat=server> <input type=submit name=submit'" + i + "' id=submit'" + i +"' value=Delete style=font - size:32px; color: red; /></form></td>";
            st += "</tr>";
        }
        st += "</table>";
        for(int i = 0; i < dt.Rows.Count; i++)
        {
            if (Request.Form["submit'" + i + "'"] != null)
            {
                Session["S1"] = ""+dt.Rows[i][4]+"";
                Session["S2"] = "" + dt.Rows[i][1] + "";
                Session["S3"] = "" + dt.Rows[i][2] + "";
                Response.Redirect("DeleteUser.aspx");         
            }
            if (Request.Form["Update'" + i + "'"] != null)
            {
                Session["S1"] = "" + dt.Rows[i][4] + "";
                Response.Redirect("UpdateUser.aspx");
            }
        }
       
   
    }
}