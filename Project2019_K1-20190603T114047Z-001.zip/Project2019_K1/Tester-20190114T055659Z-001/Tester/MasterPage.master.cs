﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class MasterPage : System.Web.UI.MasterPage
{
    public String S1 = "Hello Guest";
    public String St, Selectquerry;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["Admin"] != null)
        {
            S1 = "Hello: "+Session["Admin"]+"";
            St += "<tr style = height:100px;text-align:center><td style= width:33%;background-color:lavender;><a href = select.aspx><img width=150px src=images/Select1.png /></a></td><td style= width:34%;background-color:lavender;><a href = AdminManage.aspx><img width=150px src=images/Manage1.png /></a></td>";
            St += "<td style= width:33%;background-color:lavender;><a href = Exit.aspx><img width=150px src=images/Exit1.png /></a></td></tr>";
        }
        else if(Session["User"] != null)
        {
            Selectquerry = "SELECT Firstname From Table1" + " Where mail='" + Session["User"] + "'";
            DataTable dt = MyAdoHelper.ExecuteSelect(Selectquerry);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    Session["Name"] = dt.Rows[i][j];
                }              
            }     
            S1 = "Hello: " + Session["Name"] + "";
            St += "<tr style = height:100px;text-align:center><td style=width:25%;background-color:lavender;><a href = UpdatePassword.aspx><img width = 150px src=images/Update_1.png /></td>";
            St += "<td style=background-color:lavender;width:25%><a href = MemberWelcome.aspx><img width=150px src=images/mainpage.png /></a></td>";
            St += "<td style =background-color:lavender; width: 25 %><a href = e1.aspx><img width=150px src=images/ESCAPEROOM.png /></a ></td > ";
            St += "<td style =background-color:lavender; width: 25 %><a href = Exit.aspx><img width=150px src=images/Exit1.png /></a></td></tr>";
        }
        else
        {
            S1 = "Hello: Guest";
            St += "<tr style = height:100px;text-align:center> <td style = width:15%;background-color:lavender;><a href = Homepage.aspx ><img width = 150px src = images/Picture1.png /></ a ></td>"; ;
            St += "<td class=masteroage_td><a href = Connector.aspx><img width=150px src=images/LR.png /></a> </td>";
            St += "<td class=masteroage_td><a href = about.aspx><img width=150px src=images/Picture2.png /></a> </td>";
            St += "<td class=masteroage_td><a href = gallery.aspx><img width=150px src=images/Picture3.png /></a> </td>";
            St += "<td class=masteroage_td><a href = information1.aspx><img width=150px src=images/FlashInformation1.png /></a></td>";
            St += "<td class=masteroage_td><a href = information2.aspx><img  width=150px src=images/information2.png /></a></td>";
            St += "<td style=width:15%;background-color:lavender;><a href=information3.aspx><img width = 150px src=images/information3.png /></a></td></tr>";
        }
    }
}
