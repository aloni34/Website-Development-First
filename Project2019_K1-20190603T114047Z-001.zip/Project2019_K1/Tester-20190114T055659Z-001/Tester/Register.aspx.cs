﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    public string S1, S2,S3 ,S4, S5, S6,S7 = "", S8 = "",S9,S10 = "", S11,S12 = "No",S13 = "", correct, problem, selectqueery, m = "";
    protected void Page_Load(object sender, EventArgs e)
    {
       
            if (Request.Form["submit"] != null)
            {
                
                S1 = Request.Form["Firstname"];
                S2 = Request.Form["Lastname"];
                S3 = Request.Form["Password"];
                S4 = Request.Form["Password2"];
                S5 = Request.Form["Phone"];
                S6 = Request.Form["mail"];             
                S9 = Request.Form["age"];               
                S11 = Request.Form["Address"];

                if (Request.Form["Gender"] != null)
                {
                    S7 = Request.Form["Gender"].ToString();
                }
                if (Request.Form["areaCode"] != null)
                {
                    S8 = Request.Form["areaCode"].ToString();
                }
                if (Request.Form["Site1"] != null)
                {
                    S10 = Request.Form["Site1"].ToString();
                }
                else
                {
                }
                if (Request.Form["Training"] != null)
                {
                    S12 = Request.Form["Training"].ToString();
                }
                if (Request.Form["Food"] != null)
                {
                    S13 = Request.Form["Food"].ToString();
                }

                selectqueery = "SELECT * From Table1" + " Where mail='" + S6 + "'";
                if (!MyAdoHelper.Exists(selectqueery))
                {
                    if (S3.Equals(S4) && S3 != "" && S4 != "")
                    {
       

                        if (S6 != "" && S1 != "")
                        {
                            string SQL_COMMAND = "insert into Table1 (Firstname, Lastname,password, Phone, mail, gender, areacode, age, interests, Address, Training, Food) values('" + S1 + "', '" + S2 + "','" + S3 + "','" + S5 + "','" + S6 + "','" + S7 + "','" + S8 + "','" + S9 + "','" + S10 + "','" + S11 + "','" + S12 + "','" + S13 + "')";
                            int x = MyAdoHelper.RowsAffected(SQL_COMMAND);

                            if (x == 1)
                            {
                                Response.Write("Successful insertion");
                            }
                            else
                            {
                                Response.Write("UnSuccessful insertion");
                            }

                            Response.Redirect("login.aspx");

                        }
                        else
                        {
                            problem = "Sorry maybe you forgot to write your Mail or Username";
                        }
                    }
                    else
                    {
                        problem = ("sorry not the same password, or you didn't enter a one");
                    }
                }
                else
                {
                    problem = ("The mail already exists, please enter a diffrent mail");
                }
            }
       
    }
   

}