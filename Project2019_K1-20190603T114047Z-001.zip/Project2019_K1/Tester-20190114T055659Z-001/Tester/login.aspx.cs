﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Tester_Member : System.Web.UI.Page
{
    public string S1, S2, S3, S4, selectqueery, Option ="";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Form["submit"] != null)
        {
            S1 = Request.Form["mail"];
            S2 = Request.Form["Password2"];
            selectqueery = "SELECT * From Table1" + " Where mail='" + S1 + " 'and password='" + S2+"'";
            
            if(MyAdoHelper.Exists(selectqueery) && S1.Equals("Admin") && S2.Equals("Admin"))
            {
                Session["Admin"] = S1;
                Response.Redirect("AdminManage.aspx");
            }
            else if(MyAdoHelper.Exists(selectqueery))
            {
                Session["User"] = S1;
                Response.Redirect("MemberWelcome.aspx");
            }
            else
            {
                selectqueery = "SELECT * From Table1" + " Where mail='" + S1 + "'";
                if (MyAdoHelper.Exists(selectqueery))
                {
                    S3 = "<center><h1 style=background-color:darkturquoise>The password doesn't fit the username</h1>";
                    S4 = "<a href=Reset_Password.aspx><center><img src=images/ResetNow.png /></center></a>";
                    Session["ConfirmMail"] = S1; 
                }
                else
                {
                    S3 = "<center><h1 style=background-color:darkturquoise>Username doesn't exists</h1></center>";
                }
                Option = "<a href=Register.aspx><center><img src=images/register.png /></center></a>";
            }
        } 
    }
}
